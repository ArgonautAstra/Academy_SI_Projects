package it.corso.dto;

public class CourseUpdateDto {

}
